/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbms_metadata;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Dell
 */
public class DBMS_Metadata {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {
        
        int flag=0;
        /*System.out.println("ENTER ANY KEYWORD");
        Scanner sc = new Scanner(System.in); */
        String key =args[0]; 
        
        try{
            // CONNECTION
            String myDriver ="com.mysql.jdbc.Driver";
            String myUrl = "jdbc:mysql://localhost:3306/dbms_lab_project?zeroDateTimeBehavior=convertToNull&useSSL=false";
            Class.forName("com.mysql.jdbc.Driver");

            Connection conn = DriverManager.getConnection(myUrl, "root", "wh@tthehell!");
            DatabaseMetaData meta = conn.getMetaData();
            PreparedStatement pst;
            ResultSetMetaData rsmd ;
            ResultSet rs = null ;
            ResultSet Col_rs = null ;
            ResultSet Table_rs = null ;
            
            String table[] = {"TABLE"};
            
            Table_rs = meta.getTables(null, null, null,table);
            
            while(Table_rs.next())
            {  
                String Table_name = Table_rs.getString(3);
                System.out.println("-------"+Table_rs.getString(3)+"-------");
                
                Col_rs = meta.getColumns(null, null, Table_name, null);
                
                while(Col_rs.next()) 
                {
                    pst=conn.prepareStatement("select * from "+Table_name+" where "+Col_rs.getString("COLUMN_NAME")+" like '%"+key+"%'");
                    rs=pst.executeQuery();
                    rsmd = rs.getMetaData();


                    while(rs.next())
                    {
                        int total_col = rsmd.getColumnCount();
                        for(int i=1; i <= total_col ; i++)
                        {
                            String col_name = rsmd.getColumnName(i);
                            System.out.print(col_name+"\t");
                        }
                        System.out.println("");
                        for(int i=1; i <= total_col ; i++)
                        {
                            String col_name = rsmd.getColumnName(i);
                            System.out.print(rs.getString(col_name)+"\t");
                            flag=1;
                        }
                        System.out.println("");
                        //System.out.println(rs.getString("ID")+" " +rs.getString("name")+" "+rs.getString("dept_name")+" "+rs.getString("tot_cred"));

                    }
                }  
            }
        }
        catch(SQLException se){
        //Handle errors for JDBC
        se.printStackTrace();
        }catch(Exception e){
        //Handle errors for Class.forName
        e.printStackTrace();
   }
  }
}