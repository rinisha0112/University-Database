
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Dell
 */
@WebServlet(urlPatterns = {"/FormController"})
public class FormController extends HttpServlet {
    
    private static final String USERNAME="root";
    private static final String PASSWORD= "wh@tthehell!";
    @Override
     protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
    {
        response.setContentType("text/html");
        PrintWriter pw=response.getWriter();
        String roll_no = request.getParameter("roll");
        
        Connection conn;
        Statement stmt;
        try{
        //STEP 2: Register JDBC driver
        //Class.forName("com.mysql.jdbc.Driver");
      
      
        String myDriver ="com.mysql.jdbc.Driver";
        String myUrl = "jdbc:mysql://localhost:3306/dbms_lab_project?zeroDateTimeBehavior=convertToNull";
        Class.forName("com.mysql.jdbc.Driver");

        conn = DriverManager.getConnection(myUrl,USERNAME ,PASSWORD);
        
        //STEP 3: Open a connection
        // System.out.println("Connecting to a selected database...");
        //conn = DriverManager.getConnection(DB_URL, "root", "wh@tthehell!");
        //System.out.println("Connected database successfully...");
        if(roll_no.length()==5)
        {
               System.out.println("aa");
            
            stmt = conn.createStatement();
            
            String details = "SELECT ID, name, dept_name FROM student where ID='"+roll_no+"';";
            
            ResultSet rs = stmt.executeQuery(details);
            
            System.out.println("aaa");
             while(rs.next())
             {
                String id = rs.getString("ID");
                String name = rs.getString("name");
                String dept = rs.getString("dept_name");
            System.out.println("aa");   
                //Display values
                pw.write("<h3> Roll No: "+ id +" </h3><br>");
                pw.write("<h3> Name: "+ name +" </h3><br>");
                pw.write("<h3> Department: "+ dept +" </h3><br>");
            
             }
            rs.close();
            
            
            String course_detail="SELECT takes.course_id, grade, title, credits FROM takes, course where ID='"+roll_no+"' and takes.course_id=course.course_id;";
            
            ResultSet rs0=stmt.executeQuery(course_detail);
            pw.write("<table>"
                    + "<tr>"
                    +"<th>COURSE ID</th>"
                    +"<th>GRADE</th>"
                    +"<th>TITLE</th>"
                    +"<th>CREDITS</th></tr>");
             while(rs0.next())
             {
                 
                String cid = rs0.getString("course_id");
                String grd = rs0.getString("grade");
                String titl = rs0.getString("title");
                String cred = rs0.getString("credits");
                
               pw.write("<tr><td>"+ cid +" </td>");
                pw.write("<td>"+ grd +" </td>");
                pw.write("<td>"+ titl +" </td>");
                pw.write("<td>"+ cred +" </td></tr>");
               
                
               /* String credits="SELECT title, credits FROM course where course_id='"+cid+"';";
                
                 ResultSet rs1=stmt.executeQuery(credits);
                 
                 while(rs.next())
                 {
                     String titl = rs1.getString("title");
                    String cred = rs1.getString("credits");
                    
                     pw.write("<h3>Title: "+ titl +" </h3>");
                    pw.write("<h3> : Credits"+ cred +" </h3>");
                 }
             
                 rs1.close();*/
          
            
             }
             pw.write("</table>" );
            rs0.close();
            
           /* String course_table = "SELECT ";
            
            
            pw.write("INSERT SUCCESSFUL \n");
            pw.write("<h2> Following data received sucessfully.. <h2> <br>");
            pw.write("<h3> Roll_No: "+ roll_no +" </h3>");*/
      }
      else
      {
          pw.write("INVALID ID !");
      }
      conn.close();
   }catch(SQLException se){
      //Handle errors for JDBC
      pw.write("DUPLICATE ROLL NO ENTRY FOUND PLEASE ENTER A VALID ROLL NO !\n");
      se.printStackTrace();
      //conn.close();
   }catch(Exception e){
      //Handle errors for Class.forName
      pw.write("EE");
      e.printStackTrace();
   }
        

        
        
    }
    
}