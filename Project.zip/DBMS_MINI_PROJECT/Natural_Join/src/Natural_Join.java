/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Ankul
 */


//Join two tables


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Natural_Join {
    
    
    
    
    public static void main(String args[])
    {
        
     
        Connection conn;
        Statement st;
        try{
      //STEP 2: Register JDBC driver
      //Class.forName("com.mysql.jdbc.Driver");
      
      
       String myDriver ="com.mysql.jdbc.Driver";

            String myUrl = "jdbc:mysql://localhost:3306/dbms_lab_project?zeroDateTimeBehavior=convertToNull";

            Class.forName("com.mysql.jdbc.Driver");

             conn = DriverManager.getConnection(myUrl, "root", "wh@tthehell!");

      //STEP 3: Open a connection
     // System.out.println("Connecting to a selected database...");
      //conn = DriverManager.getConnection(DB_URL, "root", "wh@tthehell!");
      //System.out.println("Connected database successfully...");
      
      //STEP 4: Execute a query
      //System.out.println("Inserting records into the table...");
      st = conn.createStatement();
      
     ResultSet res = st.executeQuery("SELECT *FROM "+args[0]+" NATURAL JOIN "+args[1]);

        System.out.println("Building" + "\t" + "Room Number" + "\t" + "Capacity"+"\t"+"Dept_Name"+"\t"+"Budget");
        while(res.next()){
            
            String building = res.getString("building");
            int room_number = res.getInt("room_number");
            int capacity = res.getInt("capacity");
             String dept_name = res.getString("dept_name");
             int budget=res.getInt("budget");
        

        System.out.println(building + "\t\t" + room_number + "\t\t" + capacity+"\t\t"+dept_name+"\t\t"+budget);
        }    
      res.close();

   }catch(SQLException se){
      //Handle errors for JDBC
      se.printStackTrace();
   }catch(Exception e){
      //Handle errors for Class.forName
      e.printStackTrace();
   }
    
    }
}
    

