/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Ankul
 */
@WebServlet(urlPatterns = {"/FormControl"})
public class FormControl extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    
    
    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
   static final String DB_URL = "jdbc:mysql://localhost:3306/dbms_lab_project?zeroDateTimeBehavior=convertToNull";
   
   
    /*protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {*/
            /* TODO output your page here. You may use following sample code. */
           /* out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet FormControl</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet FormControl at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }*/
    
    @Override
     protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
    {
        response.setContentType("text/html");
        PrintWriter pw=response.getWriter();
        String roll_no = request.getParameter("roll");
        String name = request.getParameter("name");
        String dept_name = request.getParameter("dept_name");
        
         Connection conn;
        Statement stmt;
        try{
      //STEP 2: Register JDBC driver
      //Class.forName("com.mysql.jdbc.Driver");
      
      
       String myDriver ="com.mysql.jdbc.Driver";

            String myUrl = "jdbc:mysql://localhost:3306/dbms_lab_project?zeroDateTimeBehavior=convertToNull";

            Class.forName("com.mysql.jdbc.Driver");

             conn = DriverManager.getConnection(myUrl, "root", "wh@tthehell!");

      //STEP 3: Open a connection
     // System.out.println("Connecting to a selected database...");
      //conn = DriverManager.getConnection(DB_URL, "root", "wh@tthehell!");
      //System.out.println("Connected database successfully...");
      if(roll_no.length()==5)
      {
      
      //STEP 4: Execute a query
      pw.write("Inserting records into the table...");
      stmt = conn.createStatement();
      String insert="INSERT INTO student VALUES('"+roll_no+"','"+name+"','"+dept_name+"','0');";
      stmt.executeUpdate(insert);       
     // stmt.executeUpdate(query);
      /*sql = "INSERT INTO Registration " +
                   "VALUES "+args[0];
      stmt.executeUpdate(sql);
      sql = "INSERT INTO Registration " +
                   "VALUES (102, 'Zaid', 'Khan', 30)";
      stmt.executeUpdate(sql);
      sql = "INSERT INTO Registration " +
                   "VALUES(103, 'Sumit', 'Mittal', 28)";
      stmt.executeUpdate(sql);*/
      pw.write("INSERT SUCCESSFUL \n");
      pw.write("<h2> Following data received sucessfully.. <h2> <br>");
      pw.write("<h3> Roll_No: "+ roll_no +" </h3>");
      pw.write("<h3> Name: "+ name +" </h3>");
      pw.write("<h3> Dept_name: "+ dept_name +" </h3>");
       
       
        pw.write("</h3>");
      }
      else
      {
          pw.write("INVALID ROLL NO !");
      }
      conn.close();
   }catch(SQLException se){
      //Handle errors for JDBC
      pw.write("DUPLICATE ROLL NO ENTRY FOUND PLEASE ENTER A VALID ROLL NO !\n");
      se.printStackTrace();
      //conn.close();
   }catch(Exception e){
      //Handle errors for Class.forName
      pw.write("EE");
      e.printStackTrace();
   }
        

        
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
   
    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
   
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
