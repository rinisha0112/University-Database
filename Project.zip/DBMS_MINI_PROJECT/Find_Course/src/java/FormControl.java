/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Ankul
 */
@WebServlet(urlPatterns = {"/FormControl"})
public class FormControl extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet FormControl</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet FormControl at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        
        response.setContentType("text/html");
        PrintWriter pw=response.getWriter();
        String tl = request.getParameter("title");
       
        
         Connection conn;
        Statement stmt;
        try{
      //STEP 2: Register JDBC driver
      //Class.forName("com.mysql.jdbc.Driver");
      
      
       String myDriver ="com.mysql.jdbc.Driver";

            String myUrl = "jdbc:mysql://localhost:3306/dbms_lab_project?zeroDateTimeBehavior=convertToNull";

            Class.forName("com.mysql.jdbc.Driver");

             conn = DriverManager.getConnection(myUrl, "root", "wh@tthehell!");

      //STEP 3: Open a connection
     // System.out.println("Connecting to a selected database...");
      //conn = DriverManager.getConnection(DB_URL, "root", "wh@tthehell!");
      //System.out.println("Connected database successfully...");
      
      
      //STEP 4: Execute a query
      pw.write("Searching records in the table...");
      stmt = conn.createStatement();
      String select_contain="SELECT title ,course_id, dept_name FROM course WHERE title like '%"+tl+"%'";  
      
      
      ResultSet rs = stmt.executeQuery(select_contain);
      
      pw.write("<h2> Following Courses are found.. <h2> <br>");
      //STEP 5: Extract data from result set
      while(rs.next()){
         //Retrieve by column name
         //int id  = rs.getInt("course_id");
         String t=rs.getString("title");
         String cid = rs.getString("course_id");
         String dept_name = rs.getString("dept_name");
         //int salary = rs.getInt("salary");

         //Display values
        // System.out.print("ID: " + id);
        
             pw.write("<h3> Title: "+  t +" </h3>");
            pw.write("<h3> Course_id: "+  cid +" </h3>");
            pw.write("<h3> Department_Name: "+ dept_name +" </h3>");
       
            pw.write("</h3>");
      }
      rs.close();
     // stmt.executeUpdate(query);
      /*sql = "INSERT INTO Registration " +
                   "VALUES "+args[0];
      stmt.executeUpdate(sql);
      sql = "INSERT INTO Registration " +
                   "VALUES (102, 'Zaid', 'Khan', 30)";
      stmt.executeUpdate(sql);
      sql = "INSERT INTO Registration " +
                   "VALUES(103, 'Sumit', 'Mittal', 28)";
      stmt.executeUpdate(sql);*/
      //pw.write("INSERT SUCCESSFUL \n");
    
    
      conn.close();
   
       }
        
        catch(SQLException se){
      //Handle errors for JDBC
      pw.write("DUPLICATE ROLL NO ENTRY FOUND PLEASE ENTER A VALID ROLL NO !\n");
      se.printStackTrace();
      //conn.close();
   }catch(Exception e){
      //Handle errors for Class.forName
      pw.write("EE");
      e.printStackTrace();
   }
  }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
