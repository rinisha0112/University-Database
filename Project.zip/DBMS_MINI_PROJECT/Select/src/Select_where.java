
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Ankul
 */
public class Select_where {
    
    
      public static void main(String args[])
    {
        
     
        Connection conn;
        Statement stmt;
        try{
      //STEP 2: Register JDBC driver
      //Class.forName("com.mysql.jdbc.Driver");
      
      
       String myDriver ="com.mysql.jdbc.Driver";

            String myUrl = "jdbc:mysql://localhost:3306/dbms_lab_project?zeroDateTimeBehavior=convertToNull";

            Class.forName("com.mysql.jdbc.Driver");

             conn = DriverManager.getConnection(myUrl, "root", "wh@tthehell!");

      //STEP 3: Open a connection
     // System.out.println("Connecting to a selected database...");
      //conn = DriverManager.getConnection(DB_URL, "root", "wh@tthehell!");
      //System.out.println("Connected database successfully...");
      
      //STEP 4: Execute a query
      //System.out.println("Inserting records into the table...");
      stmt = conn.createStatement();
      
     String sql = "SELECT id, name, dept_name, salary FROM instructor WHERE "+ args[0];
      ResultSet rs = stmt.executeQuery(sql);
      //STEP 5: Extract data from result set
      while(rs.next()){
         //Retrieve by column name
         int id  = rs.getInt("id");
         String name = rs.getString("name");
         String dept_name = rs.getString("dept_name");
         int salary = rs.getInt("salary");

         //Display values
         System.out.print("ID: " + id);
         System.out.print(", NAME: " + name);
         System.out.print(", DEPARTMENT: " + dept_name);
         System.out.println(", SALARY: " + salary);
      }
      rs.close();

   }catch(SQLException se){
      //Handle errors for JDBC
      se.printStackTrace();
   }catch(Exception e){
      //Handle errors for Class.forName
      e.printStackTrace();
   }
    
    }
    
}
