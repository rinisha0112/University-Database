
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Dell
 */
@WebServlet(urlPatterns = {"/FormController"})
public class FormController extends HttpServlet {
    
    private static final String USERNAME="root";
    private static final String PASSWORD= "wh@tthehell!";
    @Override
     protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
    {
        response.setContentType("text/html");
        PrintWriter pw=response.getWriter();
        //String roll_no = request.getParameter("roll");
        
        Connection conn;
        Statement stmt;
        try{
        //STEP 2: Register JDBC driver
        //Class.forName("com.mysql.jdbc.Driver");
      
      
        String myDriver ="com.mysql.jdbc.Driver";
        String myUrl = "jdbc:mysql://localhost:3306/dbms_lab_project?zeroDateTimeBehavior=convertToNull";
        Class.forName("com.mysql.jdbc.Driver");

        conn = DriverManager.getConnection(myUrl,USERNAME ,PASSWORD);
        
        //STEP 3: Open a connection
        // System.out.println("Connecting to a selected database...");
        //conn = DriverManager.getConnection(DB_URL, "root", "wh@tthehell!");
        //System.out.println("Connected database successfully...");
        
           
            
            stmt = conn.createStatement();
            
            String details = "SELECT ID, name FROM student where ID in ( SELECT ID FROM takes where grade like 'F'  and student.ID = takes.ID group by ID having count(ID)>=2)";
            
            ResultSet rs = stmt.executeQuery(details);
            
            pw.write("<table>"
                    + "<tr>"
                    +"<th>NAME</th>"
                    +"<th>ID</th>");
            
            System.out.println("aaa");
             while(rs.next())
             {
                String id = rs.getString("ID");
                String name = rs.getString("name");
             
                //Display values
                pw.write("<tr> <td>"+ id +" </td>");
                pw.write("<td>"+ name +" </td></tr>");
            
             }
             pw.write("</table>");
            rs.close();
            
            
            
           /* String course_table = "SELECT ";
            
            
            pw.write("INSERT SUCCESSFUL \n");
            pw.write("<h2> Following data received sucessfully.. <h2> <br>");
            pw.write("<h3> Roll_No: "+ roll_no +" </h3>");*/
      
      conn.close();
   }catch(SQLException se){
      //Handle errors for JDBC
      pw.write("DUPLICATE ROLL NO ENTRY FOUND PLEASE ENTER A VALID ROLL NO !\n");
      se.printStackTrace();
      //conn.close();
   }catch(Exception e){
      //Handle errors for Class.forName
      pw.write("EE");
      e.printStackTrace();
   }
        

        
        
    }
    
}