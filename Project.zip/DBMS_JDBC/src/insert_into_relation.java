/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Ankul
 */


import java.sql.*;


public class insert_into_relation {
    
    
    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
   static final String DB_URL = "jdbc:mysql://localhost:3306/dbms_lab_project?zeroDateTimeBehavior=convertToNull";

   //  Database credentials
  
   
   
    public static void main(String args[])
    {
        
        Connection conn;
        Statement stmt;
        try{
      //STEP 2: Register JDBC driver
      //Class.forName("com.mysql.jdbc.Driver");
      
      
       String myDriver ="com.mysql.jdbc.Driver";

            String myUrl = "jdbc:mysql://localhost:3306/dbms_lab_project?zeroDateTimeBehavior=convertToNull";

            Class.forName("com.mysql.jdbc.Driver");

             conn = DriverManager.getConnection(myUrl, "root", "wh@tthehell!");

      //STEP 3: Open a connection
     // System.out.println("Connecting to a selected database...");
      //conn = DriverManager.getConnection(DB_URL, "root", "wh@tthehell!");
      //System.out.println("Connected database successfully...");
      
      //STEP 4: Execute a query
      System.out.println("Inserting records into the table...");
      stmt = conn.createStatement();
      
      String sql = "INSERT INTO classroom " +
                   "VALUES "+args[0];
      stmt.executeUpdate(sql);
      /*sql = "INSERT INTO Registration " +
                   "VALUES "+args[0];
      stmt.executeUpdate(sql);
      sql = "INSERT INTO Registration " +
                   "VALUES (102, 'Zaid', 'Khan', 30)";
      stmt.executeUpdate(sql);
      sql = "INSERT INTO Registration " +
                   "VALUES(103, 'Sumit', 'Mittal', 28)";
      stmt.executeUpdate(sql);*/
      System.out.println("Inserted records into the table...");

   }catch(SQLException se){
      //Handle errors for JDBC
      se.printStackTrace();
   }catch(Exception e){
      //Handle errors for Class.forName
      e.printStackTrace();
   }
        
    }
    
    
    
}
